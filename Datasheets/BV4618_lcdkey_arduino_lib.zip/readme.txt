There are two Arduio libraries, one for the I2C interface BV4618_I and the other for the serial interface BV4618_S. For an explanation of both see the user guide, the link of which can be found at www.byvac.com under the product description.

17/01/2011
Updates now uses BSerial - sse userguide in ASI