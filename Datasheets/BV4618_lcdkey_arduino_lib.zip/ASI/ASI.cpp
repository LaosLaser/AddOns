/*
  ASI - Main class for ASI type interface ByVac
  Copyright (c) 2011 Jim Spence.  All right reserved.
  www.byvac.com - see terms and conditions for using hardware
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
  
  Release Notes:

*/  

#include "WProgram.h"
#include "ASI.h"

// ==============================================================
// NON ADDRESS SPECIFIC SECTION
// ==============================================================
// ==============================================================
// **************************************************************
// constructor is just a connection to NewSoftSerial
// **************************************************************
ASI::ASI(uint8_t rxPin, uint8_t txPin) : BSerial(rxPin,txPin)
{
}

// **************************************************************
// set up baud rate, attach serial and initialise any devices
// that may be on the bus
// **************************************************************
void ASI::begin()
{
char b[28], *bp=b;;
    delay(100);
    init_all();
}

// **************************************************************
// initialise all devices on the bus and sets their output
// to match the Arduino NewSoftSerial
// **************************************************************
void ASI::init_all()
{
    // initialise Baud rate - the delays give a reliable
    // reset
    puts("\r"); delay(100);
    puts("\r"); delay(100);
    puts("\r"); delay(100);
    // 
    puts("\x4\r"); // invert output
    flush(); // buffer
    delay(20);
}

// **************************************************************
// reset all devices on bus
// **************************************************************
void ASI::resetall(char *dev, char max)
{
    flush();
    puts("\x3\r");
    delay(200);
    init_all();
}


// **************************************************************
// return all devices on bus, max is the buffer size to contain 
// devices. The sting is "a>d>j>.." and each device takes its
// turn, z will wait 700+ ms before sending. Wait timeout is 
// set for 1 second so this will be enough time
// **************************************************************
void ASI::devices(char *dev, char max)
{
    flush();
    puts("\x1\r");
    // all devices are lower case so just wait for timeout
    wait(dev, 'X', max);
}

// ==============================================================
// ADDRESS SPECFIC SECTION
// ==============================================================
// ==============================================================
// **************************************************************
// wait for the terminating char, normally '>' or time out 
// and return gathered input
// **************************************************************
char ASI::wait(char *inp, char term, char max)
{
#define TIMEOUT 900 // about 1 second
char c, count=0, *sp=inp;
int timeout=TIMEOUT;
    *sp='\0';
    while(timeout) {
        if(buffer()==0) {
            timeout--;
            delay(1);
            continue;
        }
        c = getch();
        if( c == term) break;
        if( count++ >= max) break;
        *(sp++)=c;
        timeout=TIMEOUT; // reset        
    }
    *sp='\0';
    return count;    
}
// alternative, just waits for '>' but returns nothing
void ASI::wait()
{
#define TIMEOUT 900 // about 1 second
int timeout=TIMEOUT;
    while(timeout) {
        if(buffer()==0) {
            timeout--;
            delay(1);
            continue;
        }
        if( getch() == '>') break;
    }
}

// **************************************************************
// changes address, the device will not respond after this unless
// begin is issued again
// changes EEPROM contents so don't use every time
// **************************************************************
void ASI::changeaddress(char DEVadr, char newadr)
{
    flush();
    // unlock first - this command does not send back >
    putch(DEVadr);
    puts("U\r");
    delay(100); // because there is no ack
    putch(DEVadr);
    puts("A");
    putch(newadr);
    puts("\r");   
    wait();
    delay(50); // because this is write to EEPROM
}

// **************************************************************
// Write string to eeprom at given address
// **************************************************************
void ASI::eepromwrite(char DEVadr, char addr, char *s)
{
char b[5];
    flush();
    putch(DEVadr);
    puts("B");
    itoa(addr,b,10);
    puts(b);
    puts(" '");
    puts(s);
    puts("\r");
    wait();
}

// **************************************************************
// turn off ack, device must be reset to turn it back on again
// **************************************************************
void ASI::ackoff(char DEVadr)
{
    flush();
    putch(DEVadr);
    puts("C\r");
    wait();
}

// **************************************************************
// turn off error reporting
// **************************************************************
void ASI::erroroff(char DEVadr)
{
    flush();
    putch(DEVadr);
    puts("E\r");
    wait();
}

// **************************************************************
// reads EEPROM into a string starting ast address for number
// of bytes
// **************************************************************
void ASI::eepromread(char DEVadr, char addr, char bytes, char *read, char max)
{
char b[5];
    flush();
    putch(DEVadr);
    puts("G");
    // start address
    itoa(addr,b,10);
    puts(b);
    puts(" "); // space between
    // number of bytes
    itoa(bytes,b,10);
    puts(b);
    puts("\r");
    wait(read, '>', max);
}

// **************************************************************
// returns device id
// **************************************************************
void ASI::deviceid(char DEVadr, char *id)
{
    flush();
    putch(DEVadr);
    puts("H\r");
    wait(id, '>', 5);
}

// **************************************************************
// run macro at start up
// **************************************************************
void ASI::macro(char DEVadr, char mon)
{
    flush();
    putch(DEVadr);
    puts("M");
    putch(mon+'0'); // 1 or 0
    puts("\r");
    wait();
}

// **************************************************************
// reset
// **************************************************************
void ASI::reset(char DEVadr)
{
    flush();
    putch(DEVadr);
    puts("R\r");
    delay(200);     // no wait device reset
}

// **************************************************************
// returns version as text string
// **************************************************************
void ASI::version(char DEVadr, char *s)
{
    flush();
    putch(DEVadr);
    puts("V\r");
    wait(s, '>', 5);
}    

