/*
  ASI - Main class for ASI type interface ByVac
  Copyright (c) 2011 Jim Spence.  All right reserved.
  www.byvac.com - see terms and conditions for using hardware
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/  

#ifndef _H_asi_h
#define _H_asi_h

#include <inttypes.h>
#include "BSerial.h"


class ASI : public BSerial
{
    public:
        // non-device specific
        ASI(uint8_t rxPin, uint8_t txPin);
        void begin();
        void resetall(char *dev, char max);
        void devices(char *dev, char max);
        char wait(char *inp, char term, char max);
        void wait();
        void changeaddress(char DEVadr, char newadr);
        void eepromwrite(char DEVadr, char addr, char *s);
        void ackoff(char DEVadr);
        void erroroff(char DEVadr);
        void eepromread(char DEVadr, char addr, char bytes, char *read, char max);
        void deviceid(char DEVadr, char *id);
        void macro(char DEVadr,char mon);
        void reset(char DEVadr);
        void version(char DEVadr, char *s);
    private:
        void init_all();
};


#endif