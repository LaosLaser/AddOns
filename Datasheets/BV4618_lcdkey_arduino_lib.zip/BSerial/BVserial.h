/*
  Buffered serial for ByVac serial devices
  Copyright (c) 2011 Jim Spence.  All right reserved.
  www.byvac.com - see terms and conditions for using hardware
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/  

#ifndef _H_BVserial_h
#define _H_BVserial_h

#include <inttypes.h>

#define TIB_MAX 32      // size of Text Input Buffer


static uint8_t _receivePin;
static uint8_t _transmitPin;
static uint8_t _rts_pin;
static uint8_t _cts_pin;
static long _baudRate;
static int _bitPeriod;
static char _tib[TIB_MAX]; // input buffer
static uint8_t _cib;       // charatres in buffer
static uint8_t _Pptr, _Gptr; // put and get pointers
static uint8_t _bfullF; // buffer full flag

// ------

void BVserial_init(char rxPin, char txPin);
void BVserial_baud(long speed);
void BVserial_handshake(char rtsPin, char ctsPin);
void BVserial_setRTS(char v);
void BVserial_flush();
char BVserial_cib();
void BVserial_fill_buf();
char BVserial_getch ();
char BVserial_read();
void BVserial_putch(uint8_t b);


#endif