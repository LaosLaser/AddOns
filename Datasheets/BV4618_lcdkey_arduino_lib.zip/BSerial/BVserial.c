/*
  Buffered serial for ByVac serial devices
  Copyright (c) 2011 Jim Spence.  All right reserved.
  www.byvac.com - see terms and conditions for using hardware
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/
/*
    Updates 2011-01-17 (2)
    * Added baud9speed0 so that the rate could be fine tuned.
    * Changed the delays to read and putch to better compensate for
      timing.        
    * Added cli() to write, this effects VT100  
*/
  
#include "WProgram.h"
#include <avr/pgmspace.h>
#include "BVserial.h"
#include <avr/interrupt.h>
#include "pins_arduino.h"

// Abstractions for maximum portability between processors
// These are macros to associate pins to pin change interrupts
#if !defined(digitalPinToPCICR) // Courtesy Paul Stoffregen
#if defined(__AVR_ATmega168__) || defined(__AVR_ATmega328P__)
#define digitalPinToPCICR(p)    (((p) >= 0 && (p) <= 21) ? (&PCICR) : ((uint8_t *)NULL))
#define digitalPinToPCICRbit(p) (((p) <= 7) ? 2 : (((p) <= 13) ? 0 : 1))
#define digitalPinToPCMSK(p)    (((p) <= 7) ? (&PCMSK2) : (((p) <= 13) ? (&PCMSK0) : (((p) <= 21) ? (&PCMSK1) : ((uint8_t *)NULL))))
#define digitalPinToPCMSKbit(p) (((p) <= 7) ? (p) : (((p) <= 13) ? ((p) - 8) : ((p) - 1/4)))
#else
#define digitalPinToPCICR(p)    ((uint8_t *)NULL)
#define digitalPinToPCICRbit(p) 0
#define digitalPinToPCMSK(p)    ((uint8_t *)NULL)
#define digitalPinToPCMSKbit(p) 0
#endif
#endif


// **************************************************************
// initialise serial
// **************************************************************
void BVserial_init(char rxPin, char txPin)
{
    _receivePin=rxPin;
    _transmitPin=txPin;
    _rts_pin=0xff; // off
    _cts_pin=0xff; // off
    digitalWrite(_transmitPin, HIGH);
    pinMode(_transmitPin, OUTPUT);
    pinMode(_receivePin, INPUT);
    // set interrupts for receive
    *digitalPinToPCICR(_receivePin) |= _BV(digitalPinToPCICRbit(_receivePin));
    *digitalPinToPCMSK(_receivePin) |= _BV(digitalPinToPCMSKbit(_receivePin));
    BVserial_flush(); 
}

// **************************************************************
// change baud rate
// **************************************************************
void BVserial_baud(long speed)
{
    _baudRate = speed;
    _bitPeriod = 1000000 / _baudRate;
    BVserial_flush();
}


// **************************************************************
// handshake, set up rts (output) and cts (input lines
// if required
// **************************************************************
void BVserial_handshake(char rtsPin, char ctsPin)
{
    if(rtsPin != 0xff) {
        _rts_pin=rtsPin;
        pinMode(_rts_pin, OUTPUT);
    }
    if(ctsPin != 0xff) {
        _cts_pin=ctsPin;
        pinMode(_cts_pin, INPUT);
    }

}

// **************************************************************
// Request to send is an output that goes low when the buffer is
// full. If the pin variable is set to 0xff then the pin is 
// ignored
// **************************************************************
void BVserial_setRTS(char v)
{
    if(v) _bfullF = 0;
    else _bfullF = 1;
    if(_rts_pin==0xff) return;
    digitalWrite(_rts_pin,v);
}

// **************************************************************
// clears buffer
// **************************************************************
void BVserial_flush()
{
	// buffer reset
	_cib=0;
	_Pptr=_Gptr=0;  // pointer initialise
	BVserial_setRTS(1);	  // buffer not full
}

// **************************************************************
// # char in buffer
// **************************************************************
char BVserial_cib()
{
    return _cib;
}

// **************************************************************
// input in serial interrupt, this fills a buffer up 
// using pre-incrementing
// **************************************************************
void BVserial_fill_buf()
{
    // there is a change after reading the last bit from low to high 
    // that causes a further interrupt so this revents counting it.	
    if (digitalRead(_receivePin) == HIGH) return;
	if((_Pptr+1) == _Gptr) BVserial_setRTS(0); // full 
    // full when trying to wrap on top of Gptr
    if(((_Pptr+1) > TIB_MAX) && _Gptr==0) BVserial_setRTS(1);
        
    // increment and check for wrap
    if(++_Pptr > TIB_MAX) _Pptr=0;

    // get and place char, also clears IR
    _tib[_Pptr]=BVserial_read();
    _cib++; // easiest way to keep track
}
			
// **************************************************************
// removes a char from the buffer if there is one, if not 
// it will return -1;
// **************************************************************
char BVserial_getch()
{
	// this point can be used to service non urgent code
	if(_cts_pin != 0xff) while(!_cts_pin); // wait device not ready
	if(!_cib) return -1;
//	while (!_cib);		// Wait for character ** Causes interrupt to stop working

//    cli();	
   	if(++_Gptr > TIB_MAX) _Gptr=0;
    char c = _tib[_Gptr]; // get char before updating buffer 
    
    // make sure recieve is enabled, buffer not full so room for more
    BVserial_setRTS(1);
    --_cib;  // redune number of char in buffer
//    sei();
    return c;	
}

// **************************************************************
// Original code from SoftwareSerial
// interrupt delay is about 20us ans pin detect is about 10us
// **************************************************************
char BVserial_read()
{
  char val = 0;
  int BitDelay = _bitPeriod - 7;
  int offset;
  
    // -12 to compensate for interrupt
    delayMicroseconds((BitDelay-12)/2); // 1/2 bit delay

    // offset of the bit in the byte: from 0 (LSB) to 7 (MSB)
    for (offset = 0; offset < 8; offset++) {
	// jump to middle of next bit
    delayMicroseconds(BitDelay);
	
	// read bit
	val |= digitalRead(_receivePin) << offset;
    }
	
	// stop bit
    delayMicroseconds(BitDelay);
    
    return val;
}

// **************************************************************
// from modified SoftwareSerial
// **************************************************************
void BVserial_putch(uint8_t b)
{
  int bitDelay = _bitPeriod - 4; // digital pin about 10us
  byte mask;

  cli();	

  digitalWrite(_transmitPin, LOW);
  delayMicroseconds(bitDelay);

  for (mask = 0x01; mask; mask <<= 1) {
    if (b & mask){ // choose bit
      digitalWrite(_transmitPin,HIGH); // send 1
    }
    else{
      digitalWrite(_transmitPin,LOW); // send 1
    }
    delayMicroseconds(bitDelay);
  }

  digitalWrite(_transmitPin, HIGH);
  delayMicroseconds(bitDelay);
  sei();
}

// **************************************************************
// Interrupt handling for fill buf
// **************************************************************

#if defined(PCINT0_vect)
ISR(PCINT0_vect)
{
  BVserial_fill_buf();
}
#endif

#if defined(PCINT1_vect)
ISR(PCINT1_vect)
{
  BVserial_fill_buf();
}
#endif

#if defined(PCINT2_vect)
ISR(PCINT2_vect)
{
  BVserial_fill_buf();
}
#endif

#if defined(PCINT3_vect)
ISR(PCINT3_vect)
{
  BVserial_fill_buf();
}
#endif


