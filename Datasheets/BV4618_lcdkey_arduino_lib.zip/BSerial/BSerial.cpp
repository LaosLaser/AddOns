/*
  Buffered serial for ByVac serial devices
  Copyright (c) 2011 Jim Spence.  All right reserved.
  www.byvac.com - see terms and conditions for using hardware
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/  

extern "C" {
  #include "BVserial.h"
}

#include "WProgram.h"
#include "BSerial.h"


// **************************************************************
// constructor
// **************************************************************
BSerial::BSerial(uint8_t receivePin, uint8_t transmitPin)
{
    BVserial_init(receivePin, transmitPin);
}

// **************************************************************
// hardware handshake, set to 0xff if not required
// **************************************************************
void BSerial::handshake(uint8_t rtsPin, uint8_t ctsPin)
{
    BVserial_handshake(rtsPin, ctsPin);
}

// **************************************************************
// change Baud rate if required
// **************************************************************
void BSerial::baud(long speed)
{
    BVserial_baud(speed);
}

// **************************************************************
// reset bufer (clear)
// **************************************************************
void BSerial::flush()
{
    BVserial_flush();
}

// **************************************************************
// put char
// **************************************************************
void BSerial::putch(char c)
{
    BVserial_putch(c);
}

// **************************************************************
// put string
// **************************************************************
unsigned char BSerial::puts(char *s)
{
unsigned char len=0;
    while(*s) { 
        BVserial_putch(*(s++));
        len++;
        if(!len) break;
    }
    return len;
}

// **************************************************************
// tests for any bytes in buffer, returns number of bytes
// **************************************************************
unsigned char BSerial::buffer()
{
    return BVserial_cib();
}

// **************************************************************
// get char
// **************************************************************
char BSerial::getch()
{
    BVserial_getch();
}


