/*
  Buffered serial for ByVac serial devices
  Copyright (c) 2011 Jim Spence.  All right reserved.
  www.byvac.com - see terms and conditions for using hardware
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/  

#ifndef _H_BSerial_h
#define _H_BSerial_h

#include <inttypes.h>
//#include "BVserial.h"

#define TIB_MAX 32      // size of Text Input Buffer

class BSerial
{
    public:
        BSerial(uint8_t receivePin, uint8_t transmitPin);
        void handshake(uint8_t rtsPin, uint8_t ctsPin);
        void baud(long speed);
        void flush();
        void putch(char c);
        unsigned char puts(char *s);
        unsigned char buffer();
        char getch();
};


#endif