/*
  BV4618_S (I2C) and (serial) charatcer display controller  ByVac
  Copyright (c) 2011 Jim Spence.  All right reserved.
  www.byvac.com - see terms and conditions for using hardware
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/  

#ifndef _H_bv4618_S_h
#define _H_bv4618_S_h

#include <inttypes.h>
#include "BSerial.h"



class BV4618_S : public BSerial
{
  public:
    BV4618_S(uint8_t rxPin, uint8_t txPin, uint8_t int_pin);
    BV4618_S(uint8_t rxPin, uint8_t txPin);
    void begin(long rate, int cdelay, char ack);
    int cmd(char *s);
    void setkeycodes(const char *codes);
    char keyint();
    char keys();
    char keyscan();
    char key();
    void clskeybuf();
    void keydebounce(char db);
  private:
    char _i2adr, _int_pin;
    char _ack;
    int _delay;
    char keyscancodes[16];
};


#endif