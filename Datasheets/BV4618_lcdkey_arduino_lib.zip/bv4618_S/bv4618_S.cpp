/*
  BSerial (I2C) and (serial) charatcer display controller  ByVac
  Copyright (c) 2011 Jim Spence.  All right reserved.
  www.byvac.com - see terms and conditions for using hardware
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
  
  Release Notes:

*/  

#include "WProgram.h"
#include "bv4618_S.h"

// **************************************************************
// normal constructor uses int pin to detect keys in keypad
// **************************************************************
BV4618_S::BV4618_S(uint8_t rxPin, uint8_t txPin, uint8_t int_pin) : BSerial(rxPin,txPin)
{
    _int_pin = int_pin;
    pinMode(_int_pin, INPUT);
}

// alternative
BV4618_S::BV4618_S(uint8_t rxPin, uint8_t txPin) : BSerial(rxPin,txPin)
{
    _int_pin = 0xff;
}

// **************************************************************
// set up baud rate, delay and ACK char
// set delay to 0 if none required and ack to 0 ditto
// **************************************************************
void BV4618_S::begin(long rate, int cdelay, char ack)
{
char b[4];
    baud(rate);    // set baud rate
    _ack = ack;
    _delay = cdelay;
    // initialise Baud rate
    puts("\r");
    delay(300);
    // set ACK if not 0
    if(_ack) {
        // needs to be a number in text
        itoa(_ack,b,10);
        // esc[<num>k
        puts("\e[");puts(b);puts("k");
        delay(300); //  ack not set up yet
    }
}

// ==============================================================
// SERIAL KEPAD
// ==============================================================
// ==============================================================

// **************************************************************
// VT100 reading information.
// No RTS available so either use a delay or ACK
// **************************************************************
int BV4618_S::cmd(char *s)
{
#define TIMEOUT 900 // about 1 second
char b[5], *bp=b;
int c, timeout=TIMEOUT;
    flush();  // clear buffer
    puts(s);   // send command
    delay(_delay);  // should be 0 for ack
    // _ack set to 0 if not implemented
    if(_ack) {
        while(timeout) {
            if(buffer()==0) { 
                timeout--;
                continue;
            }
        c = getch();
        if( c == _ack) break;
        *(bp++)=c;
        timeout=TIMEOUT; // reset
        }
    } else { // no ack given, assume all in buffer
        while(buffer()!=0) {
            *(bp++) = getch();
        }
    }                        
    *bp=0;
    // convert to a number and return
    return atoi(b);    
}            

// **************************************************************
// set up key scan code array for later use. Constructor sets
// these as all 0xff
// **************************************************************
void BV4618_S::setkeycodes(const char *codes)
{
char j;
    for(j=0;j<16;j++)
        keyscancodes[j]=*(codes++);
}

// **************************************************************
// reads interrupt pin
// **************************************************************
char BV4618_S::keyint()
{
    if(_int_pin == 0xff) return 1;
    return digitalRead(_int_pin);
}

// **************************************************************
// returns number of keys in keypad buffer
// **************************************************************
char BV4618_S::keys()
{
    return (char) cmd("\e[n");
}

// **************************************************************
// returns key scan code
// **************************************************************
char BV4618_S::keyscan()
{
    return (char) cmd("\e[k");
}

// **************************************************************
// returns key as set by key scan code
// **************************************************************
char BV4618_S::key()
{
char scan, j=15;
    scan = keyscan(); // get keycode 
    while(j+1) {
        if(scan == keyscancodes[j]) return j;
        --j;
    }
    return 0xff;
}

// **************************************************************
// clears key buffer
// **************************************************************
void BV4618_S::clskeybuf()
{
    puts("\e[c");
}

// **************************************************************
// sets keypad debounce, default is 50
// **************************************************************
void BV4618_S::keydebounce(char db)
{
char b[3];
    puts("\e[");
    itoa(db,b,10);
    puts(b);
    puts("r");
}
